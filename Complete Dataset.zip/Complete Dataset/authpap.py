from itertools import combinations

def unique_unordered_pair(x, y):
  if x < y:
    return int(x * (y - 1) + (y - x - 2)**2 / 4)
  else:
    return int((x - 1) * y + (x - y - 2)**2 / 4)

fi = open("authpap_old.txt", "r")
auth = set()
papauth = {}
    
for i in fi.readlines():
    papid, authid = map(int, i[0:-1].split("\t")) 

    auth.add(authid)
    papauth.setdefault(papid, []).append(authid)
fi.close()
authl = sorted(auth)
authd = {}
for i in range(len(authl)):
    authd[authl[i]] = i + 1
authgraph = {}
for i in papauth.values():
    for j in combinations(i, 2):
        k = unique_unordered_pair(authd[j[0]], authd[j[1]])
        if k in authgraph.keys():
            authgraph[k] += 1
        else:
            authgraph[k] = 1
fo = open("author_index.txt", "w")
for i in authl:
    fo.write(str(i) + '\t' + str(authd[i]) + '\n')
fo.close()
fou = open("author_graph_unweighted.txt", "w")
for i in combinations(authd.values(), 2):
    if unique_unordered_pair(i[0], i[1]) in authgraph.keys() :
        fou.write(str(i[0]) + '\t' + str(i[1]) + '\n')
fou.close()
fow = open("author_graph_weighted.txt", "w")
for i in combinations(authd.values(), 2):
    if unique_unordered_pair(i[0], i[1]) in authgraph.keys() :
        fow.write(str(i[0]) + '\t' + str(i[1]) + '\t' + str(authgraph[unique_unordered_pair(i[0], i[1])]) + '\n')
fow.close()

import networkx as nx
from operator import itemgetter


G = nx.read_edgelist("author_graph.txt")
#print(nx.average_clustering(G))
hlist, alist = nx.hits(G, max_iter=1000)
sorted_hlist = sorted(hlist.items(), key=itemgetter(1), reverse=True)
sorted_alist = sorted(alist.items(), key=itemgetter(1), reverse=True)

fo = open("hub_score.txt", "w")
fr = open("authority_score.txt", "w")

for i in sorted_hlist:
	fo.write(str(i[0])+'\t'+str(i[1])+'\n')
fo.close()

for i in sorted_alist:
	fr.write(str(i[0])+'\t'+str(i[1])+'\n')
fr.close()

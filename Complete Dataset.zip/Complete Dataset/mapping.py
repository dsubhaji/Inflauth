import networkx as nx 
import numpy as np 

mapping = {}
G = nx.read_edgelist("author_lcc_out.txt")
mapping = dict(zip(G.nodes(), range(0, nx.number_of_nodes(G))))
inv_mapping = {}
inv_mapping = dict((v,k) for k,v in mapping.items())

fi = open("inv_mapping.txt", "w")
for i in range(0, nx.number_of_nodes(G)):
	fi.write(str(i) + '\t' + str(inv_mapping[i]) + '\n')
fi.close()

#fo = open("mapping.txt", "w")
#for i in range(0, nx.number_of_nodes(G)):
#	fo.write(str(i) + '\t' + str(mapping[i]) + '\n')
#fo.close()

mapping1 = {}
fa = open("hm1.txt", "r")
fb = open("full_mapping.txt", "w")
while True:
	s = fa.readline()
	if not s: break
	a = s.split()[0]
	b = s.split()[1]
	mapping1[b] = int(a)

for i in range(0, nx.number_of_nodes(G)):
	fb.write(str(i) + '\t' + str(mapping1[inv_mapping[i]]) + '\n')

fa.close()
fb.close()

fo = open("author_lcc_out.txt", "w")
fii = open("author_lcc_hashed.txt", "r")

while True:
	s = fii.readline()
	if not s: break
	a = s.split()[0]
	b = s.split()[1]
	fo.write(str(mapping[a]) + '\t' + str(mapping[b]) + '\n')

fo.close()
fii.close()
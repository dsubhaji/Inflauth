input = open ('authpap.txt','r')
n = 2072799
count = {}

for i in range(n):
	count[i] = 0

while True:
    s = input.readline()
    if not s: break
    a = s.split()[0]
    b = s.split()[1]
    a = int(a)
    b = int(b)
    count[a] = count[a]+1
    
input.seek(0)

output = open ('authpap_woso.txt','w+')

while True:
    s = input.readline()
    if not s: break
    a = s.split()[0]
    b = s.split()[1]
    a = int(a)
    b = int(b)
    if count[a] > 1:
    	output.write(s)
    	
output.close()   
   
input.close()

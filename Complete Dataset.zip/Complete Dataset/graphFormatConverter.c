#include<stdio.h>
#include<stdlib.h>

int main(void)
{
    int temp, tempElem[2], existsCount=0, minLabel=99999, maxLabel=0;
	int nodeFrom, nodeTo, i, j;
	int *degree, **adjList, min, max;


	FILE *fp, *fq, *fr;
	fp = fopen("author_lcc_out.txt", "r");

	while(fscanf(fp,"%d %d", &nodeFrom, &nodeTo)!=EOF)
	{
		if(nodeTo == nodeFrom)
			continue;

		if(nodeFrom > nodeTo)
		{
			temp = nodeTo;
			nodeTo = nodeFrom;
			nodeFrom = temp;
		}

		if(nodeFrom < minLabel)
			minLabel = nodeFrom;

		if(nodeTo > maxLabel)
			maxLabel = nodeTo;
	}
	printf("\nNode labels: %d to %d, Total # %d\n", minLabel, maxLabel, maxLabel-minLabel+1);

/*
	rewind(fp);

	max = 0;

	fq = fopen("author_lcc_intermediate.txt", "w+");

	while(fscanf(fp,"%d %d", &nodeFrom, &nodeTo)!=EOF)
	{
	    if(nodeFrom == maxLabel)
	    {
            fprintf(fq, "%d %d\n", max, nodeTo);
	    }
	    else if(nodeTo == maxLabel)
	    {
	        fprintf(fq, "%d %d\n", nodeFrom, max);
	    }
	    else
	    {
	        fprintf(fq, "%d %d\n", nodeFrom, nodeTo);
	    }
	}

    rewind(fq);
    fclose(fp);
    */

	rewind(fp);
	degree = (int*)calloc(maxLabel-minLabel+2,  sizeof(int));
	while(fscanf(fp,"%d %d", &nodeFrom, &nodeTo)!=EOF)
	{
		if(nodeTo == nodeFrom)
			continue;

		if(!degree[nodeFrom])
			existsCount++;

		if(!degree[nodeTo])
			existsCount++;

		degree[nodeFrom]++;
		degree[nodeTo]++;
	}

/*
	if(existsCount == maxLabel-minLabel+1)
		printf("\nThere is no missing node\n");
	else
	{
		printf("\nNumber of missing nodes: %d", maxLabel-minLabel+1-existsCount);
/* missing nodes can be addressed here by implementing a function that can be called right here */
//		exit(0);
//	}


/* repetition of edges should also be addressed */

	adjList = (int**)calloc(maxLabel-minLabel+2, sizeof(int*));
	for(i=1; i<=maxLabel-minLabel+1; i++)
		adjList[i] = (int*)calloc(degree[i]+1, sizeof(int));

	rewind(fp);

	for(i=1; i<=maxLabel-minLabel+1; i++)
	{
//		printf("%d ", degree[i]); /* checking degree of nodes */
		degree[i] = 0;
	}
	printf("\n");

	//flag = (int*)calloc(maxLabel-minLabel+1, sizeof(int));

	while(fscanf(fp,"%d %d", &nodeFrom, &nodeTo)!=EOF)
	{
		degree[nodeFrom]++;
		degree[nodeTo]++;
		adjList[nodeFrom][degree[nodeFrom]] = nodeTo;
		adjList[nodeTo][degree[nodeTo]] = nodeFrom;
		adjList[nodeFrom][0] = degree[nodeFrom];
		adjList[nodeTo][0] = degree[nodeTo];
	}

	fclose(fp);

//  printing the adjacency list of the input graph

/*
    printf("\n%d \\\\numNodes\n\n", maxLabel-minLabel+1);

	for(i=0; i<=maxLabel-1; i++)
	{
		printf("%d ", i);
		for(j=0; j<=degree[i]; j++)
		{
			if(j==0)
				printf("(%d): ", adjList[i][j]);
			else
				printf("%d ", adjList[i][j]);
		}
		printf("\n");
	}
*/


    fr = fopen("author_lcc_graph.dat", "w+");

    fprintf(fr, "\n%d \\numNodes\n\n", maxLabel-minLabel+1);

	for(i=1; i<=maxLabel; i++)
	{
		fprintf(fr, "%d ", i-1);
		for(j=0; j<=degree[i]; j++)
		{
			if(j==0)
				fprintf(fr, "(%d) ", adjList[i][0]);
			else
				fprintf(fr, "%d ", adjList[i][j]-1);
		}
		fprintf(fr, "\n");
	}

	fclose(fr);

    return 0;
}

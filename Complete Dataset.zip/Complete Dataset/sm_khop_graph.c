//22 June 2013, contact kundu@csc.lsu.edu for comments and questions
// Modified by SM in the period 27th June to July 5th.
// Modified sm_khop_tree.c by SM
// Started 8th July 2013
// Heuristic for minimum K-cover of a graph
//The porgrams has are many output-statements to show the details of computations to help debugging
//To see them all do gcc -Ddebug sm_khop_tree.c


#include <stdio.h>
#include <stdlib.h>


typedef struct tNode{
	int nodeNo;
    int degree;
	int *adjNodes; //array of adjacent nodes;
	int level;
	int parent;
	int cover;
	int hopCount;
} TreeNode;

int K = 10; // this is the k for k-hop, may read it later from a file or load it as an user input

int numNodes = 0;
TreeNode **tree; //array of size numNodes

int *levelList = NULL;

int *queue = NULL;
int rearQ, frontQ;
int result[10000], finalResult[10000], min, minIndex;

void initializeQueue()
{
	queue = (int *) malloc(numNodes * sizeof(int));
	rearQ = -1;
	frontQ = 0;
}

void freeUpQ()
{
	if(queue)
		free(queue);
}

int isEmptyQ()
{
	if(rearQ == frontQ -1)
		return 1;
	else
		return 0;

}

void enQueue(int x)
{
	queue[++rearQ] = x;
}

int deQueue()
{
	frontQ++;
	return(queue[frontQ -1]);
}

void printLevels()
{
	TreeNode *printNode = NULL;
	int i;

	//printf("\n");
	for(i = 0; i < numNodes; i++)
	{
		printNode = tree[i];
//#ifdef debug
		printf("node = %d, Parent = %d, Level = %d\n", printNode->nodeNo, printNode->parent, printNode->level);
//#endif
	}
}

int printResult()
{
	//printf("\n");
	int i, sizeS = 0;
	TreeNode *printNode = NULL;

	//printf("\nPrinting final Result:\n\n");
	for(i = 0; i < numNodes; i++)
	{
		printNode = tree[i];
		int level = printNode->level;
		int cover =  printNode->cover;
/*
#ifdef debug
		printf("node = %d, Level = %d Cover = %d,\n", i, level, cover);
#endif
*/
		if(i == cover)
		{
			//printf(" %d ", i);
			sizeS++;
            result[sizeS-1] = i;
		}
	}
	//printf("Size of influential set is %d\n", sizeS);
	return sizeS;
}

void printFinalResult()
{
	printf("\n");
	int i, sizeS = 0;
	TreeNode *printNode = NULL;
    for(i=0; i<10000; i++) result[i]=-1;
	//printf("\nPrinting final Result:\n\n");
	for(i = 0; i < numNodes; i++)
	{
		printNode = tree[i];
		int level = printNode->level;
		int cover =  printNode->cover;
/*
#ifdef debug
		printf("node = %d, Level = %d Cover = %d,\n", i, level, cover);
#endif
*/
		if(i == cover)
		{
			//printf("%d ", i);
			sizeS++;
            result[sizeS-1] = i;
		}
	}
	printf("\nSize of influential set is %d, taking root %d\n", min, minIndex);
}

void PrintIntVector(int *vector, int size)
{ int i;
  for (i=0; i<size; i++) printf("%3d ", vector[i]);
  printf("\n");
}

void SkipToEndOfLine(FILE *fpInp)
{ while (getc(fpInp) != '\n');
}

void ReadInput() //creates tree
{ int i, j, node, degree, adjNode, *adjNodes;
  FILE *fpInp;

  if ((fpInp = fopen("author_lcc_graph.dat", "r")) == NULL)
     { fprintf(stderr, "Cannot open graph.dat\n"); exit(1); }
  fscanf(fpInp, "%d", &numNodes); SkipToEndOfLine(fpInp);
  tree = (TreeNode **)malloc(numNodes * sizeof(TreeNode*));
  for (i=0; i<numNodes; i++) {
      fscanf(fpInp, "%d ( %d ):", &node, &degree);

      // Rright now it is assumed that there is no gap in the node numbers
      // Hence the nodes are stored in the array in the same index as its number
      // However if there are gaps in the following few lines tree[node] should be replaced with tree[i]

      tree[node] = (TreeNode *)malloc(sizeof(TreeNode));
      tree[node]->nodeNo = node;
      tree[node]->degree = degree;
      tree[node]->adjNodes = (int *)malloc(degree * sizeof(int));
      for (j=0; j<degree; j++)
          fscanf(fpInp, "%d", &tree[node]->adjNodes[j]);

      tree[node]->level = -1;
      tree[node]->parent = -1;
      tree[node]->cover = -1;
      tree[node]->hopCount = 0;

      SkipToEndOfLine(fpInp);
      //printf("adjNodes of node %d: ", node);
      //PrintIntVector(tree[node]->adjNodes, tree[node]->degree);
  }
  fclose(fpInp);
}

void assignLevels(int ROOT)
{
        int listHead = 0;
        if(numNodes < 1)
        {
                fprintf(stderr, "Tree does not exist\n");
                exit(1);
        }

        initializeQueue();
        tree[ROOT]->level = 0;
        levelList = (int*) malloc(numNodes*(sizeof(int)));
        levelList[listHead] = ROOT;
        enQueue(ROOT);

        while(!isEmptyQ())
        {
                int currentNode = deQueue();
                int currentLevel = tree[currentNode]->level;
                int i;
                for(i=0; i < tree[currentNode]->degree; i++)
                {
                        int x = tree[currentNode]->adjNodes[i];
                        if(tree[x]->level == -1)
                        {
                                tree[x]->level =  currentLevel + 1;
                                tree[x]->parent =  currentNode;
                                levelList[++listHead] = x;
                                enQueue(x);
                        }
                }
        }
        freeUpQ();
        //free(levelList);
}

/*
#ifdef debug
void printCover(int node, int cover)
{
	printf("Node %d is covered by %d\n", node, cover);
}
#endif
*/

void computeKHopCover(int ROOT)
{
	int listHead = numNodes - 1;

	//printf("\nRunning K-hop algorithm for K = %d\n\n", K);
	while(listHead >= 0)
	{
		// It is sure that listHead points to an uncovered node

		// Locate the k th ancestor
		int influential = -1;
		int ancestor = levelList[listHead];
		int goUp;
//#ifdef debug
		//printf("Node %d is the next uncovered node with highest level value, starting to traverse up\n\n",ancestor);
//#endif
		for(goUp = 0; goUp < K; goUp++)
		{
			if(ancestor == ROOT) //i.e. root
			{
				influential = ancestor;

				//printf("Upward traversal ends at root node %d, it is added to S\n\n", ancestor);

/*
#ifdef debug
				if(tree[ancestor]->cover != -1)
					printf("Covering Node %d again\n", ancestor);
				//printCover(ancestor, influential);
#endif
*/
				tree[ancestor]->cover = influential;
				break;
			}
			ancestor = tree[ancestor]->parent;
			if(tree[ancestor]->cover != -1)
			{
				if(tree[ancestor]->hopCount > 0 && ((goUp + 1) + tree[ancestor]->hopCount <= K))
				{
					influential = tree[ancestor]->cover;
/*
//#ifdef debug
					printf("Upward traversal stops by hopCount check at node %d after %d steps\n", ancestor, (goUp + 1));
					printf("So use its cover %d to cover the subtree\n", influential);
//#endif
*/
					break;   //no need to find the kth ancestor
				}
			}
		}

		if(goUp == K) // so this is a kth ancestor
		{
			influential = ancestor;
			//printf("Upward traversal ends after K steps, adding node %d to S\n\n", influential);
/*
#ifdef debug
			if(tree[ancestor]->cover != -1)
				printf("Covering Node %d again\n", ancestor);
			printCover(ancestor, influential);
#endif
*/
			tree[ancestor]->cover = influential;

			//printf("\nWill now cover at most %d ancestors of %d\n\n", K, ancestor);
			//now cover the k ancestors
			int immParent = ancestor;
			int i;
			for(i = 0; i < K; i++)
			{
				immParent = tree[immParent]->parent;
				if(immParent == -1) //This is root, so stop going up
					break;
				//printf("Covering %d th ancestor node %d while going up from %d\n", (i + 1), immParent, influential);

/*
#ifdef debug
				if(tree[immParent]->cover != -1)
					printf("Covering Node %d again\n", immParent);
				printCover(immParent, influential);
#endif
*/
				tree[immParent]->cover = influential;
				tree[immParent]->hopCount = i + 1;
			}
		}


		// Mark the entire subtree hanging from ancestor as covered
		// Also make ancestor's hopCount = -1, means no further down traversal is necessary
		initializeQueue();
		enQueue(ancestor);
		tree[ancestor]->hopCount = -1;

		// Enhancement to fix the bug found by Prof. Kundu
		// earlier the BFS was kept unlimited thinking that it will not go beyond K levels.
		// However that assumption is true only for uncovered nodes, not for the covered nodes
		int doBFSuptoLevel = K; // if ancestor himself is influential, it should happen up to K levels
		if(tree[ancestor]->cover != ancestor && tree[ancestor]->hopCount > 0)
		{
			doBFSuptoLevel = K - tree[ancestor]->hopCount;
		}

//#ifdef debug
		//printf("\nWill now cover all the nodes in the subtree of %d\n\n", ancestor);
//#endif


		while(!isEmptyQ())
		{
			int currentNode = deQueue();
			// Added to fix the bug found by Prof. Kundu
			if(tree[currentNode]->level - tree[ancestor]->level >= doBFSuptoLevel)
				continue;
			int i;
			for(i = 0; i < tree[currentNode]->degree; i++)
			{
				int x = tree[currentNode]->adjNodes[i];
				if(tree[currentNode]->parent != x) // Do not traverse back the tree edge
				{
					if(tree[x]->hopCount != -1) //Otherwise BFS should stop at x, should not go down
					{
						//added following block for graph
						//to tackle cross edges
						if(tree[x]->parent == currentNode)
						{
/*
#ifdef debug
							if(tree[x]->cover != -1)
								printf("Covering Node %d again\n", x);
							printCover(x, influential);
#endif
*/
							tree[x]->cover = influential;
							enQueue(x);

						}
						else
						{
							//This is a cross edge
							int jumps = (tree[currentNode]->level - tree[influential]->level) + 1;
							if(jumps <= K && (tree[x]->cover == -1 || tree[x]->hopCount > jumps))
							// if x is covered by subtree cover assignment it will not take part again in traversal
							// also note that it is not enqueued
							{
								tree[x]->cover = influential;
								tree[x]->hopCount = jumps;
								//printf("Cross edge - cover of %d is now same as cover of %d, which is %d, hopCount = %d\n",x, currentNode, influential, jumps);
							}

						}
						//graph block ends here
					}
				}
			}
		}
		freeUpQ();
//#ifdef debug
		//printf("\nCovering the subtree of %d finished\n\n", ancestor);
//#endif

		listHead--;
		while(listHead >=0 && tree[levelList[listHead]]->cover != -1)
		{
			listHead--;
		}

	}
	//free(levelList);
}

void reInitialize()
{
	int i;
	for(i = 0; i < numNodes; i++)
	{
		tree[i]->level = -1;
		tree[i]->parent = -1;
		tree[i]->cover = -1;
		tree[i]->hopCount = 0;
	}

}

void runAllVerticesAsRoots()
{
	//If you want to run this function, please note that
	//the tree must be input as an undirected tree and not as a rooted tree, i
	//i.e., the end vertices of an edge should appear in both the adjacency lists of each other.

 	int i, j, size;
 	for(i = 1; i < numNodes; i++) // ROOT = 0 is already done
 	{
 		reInitialize();
 		//printf("\nROOT = %d", i);
 		assignLevels(i);
 		computeKHopCover(i);
 		size = printResult();
 		//printf("\n Size = %d, min = %d\n", size, min);
 		if(size < min)
 		{
 		    min = size;
 		    minIndex = i;
 		    for(j=0; j<size; j++) finalResult[j] = result[j];
 		}
 		free(levelList);
 	}
}

void main()
{
    int i, size;

	ReadInput();

	//printf("\nROOT = 0");
	assignLevels(0);
	//printLevels();
	computeKHopCover(0);
	size = min = printResult();
	//printf(", Size = %d, min = %d", size, min);

	runAllVerticesAsRoots();
	//computeKHopCover(minIndex);
	printFinalResult();
	PrintIntVector(finalResult, min);
}


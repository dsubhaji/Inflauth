#Takes edgeList as input file and writes the edgelist of the largest weakly-connected-component in another file.
#Please make sure your file name ends with a .txt extension, otherwise the program may give undesirable outputs

import networkx as nx
import sys

def main(argL):
	if len(argL) != 2:
		print("Please provide input as : python fWeakC.py filename.txt")
		sys.exit(1)
	
	inFile = argL[1]
	outFile = inFile[:-4] + "_out.txt"
	
	#open the input file.

	try:
		inBuf = open(inFile,"rb")
	except:
		print("Couldn't open the file! Please check the filename and try again.")
		sys.exit(0)
	
	myGraph = nx.read_edgelist(inBuf)
	print("Total nodes",nx.number_of_nodes(myGraph))
	print("No. of CC", nx.number_connected_components(myGraph))
	l = sorted(nx.connected_components(myGraph), key = len, reverse=True)
	print("Sizes of top 3 CC", len(l[0]), len(l[1]), len(l[2]))
	inBuf.close()
	
	#get the largest connected component SubGraph
	#print myGraph.edges()
	#print(list(nx.connected_component_subgraphs(myGraph))[0])
	#largestC = nx.connected_component_subgraphs(myGraph)[0]
	largestC = sorted(nx.connected_component_subgraphs(myGraph), key = len, reverse=True)[0]
	print(nx.number_of_nodes(largestC))
	n = nx.number_of_nodes(largestC)
	mapping = dict(zip(largestC.nodes(), range(1,n+1)))
	#largestC.remove_edges_from(largestC.selfloop_edges())
	largestC = nx.relabel_nodes(largestC, mapping)
	
	#print(mapping)

	inv_mapping = {}
	inv_mapping = dict((v,k) for k,v in mapping.items())

	#open a file for writing.
	f = open("hm2.txt","w")
	for i in range(1, nx.number_of_nodes(largestC)+1):
		f.write(str(i) + '\t' + str(inv_mapping[i]) + '\n')
	f.close()
	

	mapping1 = {}
	fa = open("hm1.txt", "r")
	fb = open("full_mapping.txt", "w")
	while True:
		s = fa.readline()
		if not s: break
		a = s.split()[0]
		b = s.split()[1]
		mapping1[b] = int(a)


	for i in range(1, nx.number_of_nodes(largestC)+1): #in dat file node labels are reduced by margin of 1
		fb.write(str(i-1) + '\t' + str(mapping1[inv_mapping[i]]) + '\n')

	fa.close()
	fb.close()


	outBuf = open(outFile,"w")

	nx.write_edgelist(largestC,outFile,data = False)
	outBuf.close()
	
	print("Output file with filename : " + outFile + " has been created in the same directory as " + inFile)

main(sys.argv)
		

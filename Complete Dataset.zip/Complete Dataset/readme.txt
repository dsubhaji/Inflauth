Step 1. 
----------
Start by gathering a file where all the papers with more than one author are listed in terms of paperid and authorid. If paper 134265 has been written by 76 and 98, then we will have two records from this paper, listed as,
134265	76
134265	98

If single author papers are there in the file, use a pre-processing code to remove them. You may use 'remove_single_author.py'.

Step 2.
---------- 
Once the paperid and authorid pairs are there in the file as we want them (without single author papers), use 'authpap.py' to generate the first hash-map and the unweighted graph. The input should be renamed to 'authpap_old.txt'. Run the program by command,
python authpap.py

New files will be generated. Rename the 'author_index.txt' to 'hm1.txt' and 'author_graph_unweighted.txt' to 'author_lcc.txt'.

Step 3.
----------
Run fWeakC.py to extract the largest connected component for getting the final graph to run the k-hop code. Use command,
python fWeakC.py author_lcc.txt

It will create files 'author_lcc_out.txt', 'hm2.txt' (second hash-map) and 'full_mapping' (hash-map the first set to the last set).

Step 4.
----------
Use graphFormatConverter.c to convert 'author_lcc_out.txt' to 'author_lcc_out.dat'.

Step 5.
----------
Use 'author_lcc_out.dat' to find kHDS by using the k-hop program.

